# Patch package application guide (for Claude Code on another machine)

This package set is the **full set of changes** to `alfworld-preexp-npu`, generated against `cs5446-master.zip`
(the baseline commit recorded in the zip comment = `79d011256121bb23d96d6d7055c6f68a9fd6fdb9`; same baseline as the previous set, `alfworld-patch/part01–07`).

Snapshot time **2026-10-13**. Split into **24** small packages, **each ≤ 50 KB gzipped**. This file and `SHA256SUMS.txt` are identical in every package;
`RESTORED_FILES.sha256` (the per-file checksums for restoration) is in **part01** only.

Relative to the baseline: **204 files (193 added / 11 modified), +30990 / −702 lines**; of which code (`preexperiments/` etc.) is 31 files, +3548 / −104 lines.

> **This set supersedes the previous `alfworld-patch/part01–07`** (it already contains all of their changes, plus anything changed afterwards, such as the later version of
> `direction_b/pipeline.py`). Apply it to a **freshly unzipped baseline**; do not stack it on a directory that already has the old set applied (that would conflict).
>
> **Verified on this machine**: unzip the baseline zip fresh → `git apply --check` passes for all patches → after applying, all 204 files in `RESTORED_FILES.sha256`
> match their SHA256 on this machine exactly.

---

## Package list

| Package | Files | Contents (by directory) | Patch size (gzip) |
|---|---|---|---|
| `part01-code.tar.gz` | 15 (A8/M7) | `preexperiments/common/`, `preexperiments/configs/`, `preexperiments/tests/`, `preexperiments/world_model_utility/`×2, `preexperiments/direction_b/`×4, `react_study/*.py`×6 **+ RESTORED_FILES.sha256** | 33 KB |
| `part02-code+docs.tar.gz` | 17 (A16/M1) | `react_study/*.py`×14, `react_study/assets/`×2, `README.md` | 33 KB |
| `part03-docs+results-old.tar.gz` | 9 (A7/M2) | `README_CN.md`, `README_NPU_SETUP.md`, `outputs/tables/`×4, `reports/`×2, `results/ (round 1)` | 30 KB |
| `part04-results-old-1.tar.gz` | 1 (A1/M0) | `results/ (round 1)` | 37 KB |
| `part05-results-old-2.tar.gz` | 8 (A8/M0) | `results/ (round 1)`×8 | 38 KB |
| `part06-results-old-3.tar.gz` | 6 (A5/M1) | `results/ (round 1)`×5, `results_temp02_spec/` | 16 KB |
| `part07-results-old-4.tar.gz` | 7 (A7/M0) | `results/ (round 1)`×7 | 39 KB |
| `part08-react-study-summaries-1.tar.gz` | 20 (A20/M0) | `outputs/react_study/README.md`, `outputs/react_study/stage1_protocol_logging`, `outputs/react_study/stage1_protocol_logging/tables`×10, `outputs/react_study/stage2_baselines`, `outputs/react_study/stage2_baselines/tables`×7 | 28 KB |
| `part09-react-study-summaries-2.tar.gz` | 19 (A19/M0) | `outputs/react_study/stage2_baselines/tables`×2, `outputs/react_study/stage3_paired_branching`, `outputs/react_study/stage3_paired_branching/tables`×5, `outputs/react_study/step0_protocol_v2_measurement`×2, `outputs/react_study/step0_protocol_v2_measurement/tables`×9 | 35 KB |
| `part10-react-study-summaries-3.tar.gz` | 14 (A14/M0) | `outputs/react_study/step1_upper_bound_controls`×2, `outputs/react_study/step1_upper_bound_controls/tables`×9, `outputs/react_study/step2_episodic_memory`×2, `outputs/react_study/step2_episodic_memory/tables` | 35 KB |
| `part11-react-study-summaries-4.tar.gz` | 14 (A14/M0) | `outputs/react_study/step2_episodic_memory/tables`×4, `outputs/react_study/step3_gating`×2, `outputs/react_study/step3_gating/tables`×8 | 36 KB |
| `part12-react-study-summaries+react-study-branchdata.tar.gz` | 15 (A15/M0) | `outputs/react_study/step4_unseen_test`×4, `outputs/react_study/step4_unseen_test/tables`×8, `outputs/react_study/stage1_protocol_logging/raw`, `outputs/react_study/stage2_baselines/raw`, `outputs/react_study/stage3_paired_branching/raw` | 32 KB |
| `part13-react-study-branchdata-1.tar.gz` | 3 (A3/M0) | `outputs/react_study/stage3_paired_branching/raw`×3 | 32 KB |
| `part14-react-study-branchdata-2.tar.gz` | 3 (A3/M0) | `outputs/react_study/stage3_paired_branching/raw`×3 | 33 KB |
| `part15-react-study-branchdata-3.tar.gz` | 3 (A3/M0) | `outputs/react_study/stage3_paired_branching/raw`×3 | 32 KB |
| `part16-react-study-branchdata-4.tar.gz` | 4 (A4/M0) | `outputs/react_study/stage3_paired_branching/raw`×3, `outputs/react_study/step0_protocol_v2_measurement/raw` | 38 KB |
| `part17-react-study-branchdata-5.tar.gz` | 3 (A3/M0) | `outputs/react_study/step0_protocol_v2_measurement/raw`×3 | 31 KB |
| `part18-react-study-branchdata-6.tar.gz` | 3 (A3/M0) | `outputs/react_study/step0_protocol_v2_measurement/raw`×3 | 33 KB |
| `part19-react-study-branchdata-7.tar.gz` | 4 (A4/M0) | `outputs/react_study/step0_protocol_v2_measurement/raw`×4 | 37 KB |
| `part20-react-study-branchdata-8.tar.gz` | 3 (A3/M0) | `outputs/react_study/step0_protocol_v2_measurement/raw`×3 | 32 KB |
| `part21-react-study-branchdata-9.tar.gz` | 4 (A4/M0) | `outputs/react_study/step0_protocol_v2_measurement/raw`×4 | 35 KB |
| `part22-react-study-branchdata-10.tar.gz` | 5 (A5/M0) | `outputs/react_study/step0_protocol_v2_measurement/raw`×5 | 38 KB |
| `part23-react-study-branchdata-11.tar.gz` | 18 (A18/M0) | `outputs/react_study/step0_protocol_v2_measurement/raw`×3, `outputs/react_study/step1_upper_bound_controls/raw`×12, `outputs/react_study/step3_gating/raw`×3 | 29 KB |
| `part24-react-study-branchdata-12.tar.gz` | 6 (A6/M0) | `outputs/react_study/step3_gating/raw`, `outputs/react_study/step4_unseen_test/raw`×5 | 10 KB |

**part01–part02 are the code** (this round's main addition is the `preexperiments/react_study/` package: ReAct world-model study, protocol v2, online memory, gating, Progress Rate, etc.).
part02–part03 contain the docs; part03–part07 are round-1 (September) `results/` and `outputs/tables/`; part08–part12 are this round's `outputs/react_study/` summaries
(each stage's README, tables, launch scripts); part12–part24 are state-level branch data and task lists (needed to re-run the stage3 / step0-0c analyses).
To restore only the code: part01 + part02 is enough (part01 must be included because it carries the checksums).

## How to apply

The packages touch disjoint files, so the order does not matter.

```bash
# 1. Unzip a clean baseline from the original zip (do not apply onto a directory that already has changes)
unzip cs5446-master.zip -d /path/to/dest
cd /path/to/dest/cs5446-master/alfworld-preexp-npu

# 2. Unpack the received packages and collect the *.patch files in one place
mkdir -p /tmp/patches
for t in /path/to/part*.tar.gz; do tar xzf "$t" -C /tmp/patches --strip-components=1; done

# 3. Check transfer integrity
(cd /tmp/patches && sha256sum -c SHA256SUMS.txt)

# 4. Dry-run first, then apply
git apply --check /tmp/patches/*.patch
git apply /tmp/patches/*.patch

# 5. Verify restoration: every line should be OK (if only some packages were applied, use --ignore-missing or just look at the relevant lines)
sha256sum -c /tmp/patches/RESTORED_FILES.sha256
```

The target directory does **not** need to be a git repository. Some CSV/JSONL data lines contain trailing whitespace, so `git apply` prints
`whitespace errors` warnings; these are harmless (step 5 still passes).

## What changed in this round (relative to the previous set)

- **New `preexperiments/react_study/`** (21 .py + 2 assets): metered multi-endpoint LLM (`common.py`), six/eight arms + oracle / loop-hint / pre-call gate
  (`agent.py`), AgentBoard-style ReAct protocol v2 (`protocol_v2.py`), AgentBoard Progress Rate (`progress.py`, matches the 134 official labels),
  online Episodic Memory (`online_memory.py`), K-continuation branching (`branch_k.py`), learned gate (`gate.py`), and the analysis /
  statistics / best-of-k / power scripts. Existing code is untouched apart from a few modifications already present in the previous set.
- **`outputs/react_study/`**: READMEs (design / results / conclusions), tables and launch scripts for round 1 (stage1–3) and round 2 (step0–4); index at `outputs/react_study/README.md`.

## Not included (intentionally)
- **Episode-level raw JSONL** (`outputs/react_study/*/raw/**/<arm>__rep*.jsonl`, about 670 MB), memory banks (`*.memory*.jsonl`), and run `logs/`:
  too large for small packages; every conclusion and table can be read from the tables / READMEs that are included. Only the state-level branch data and task lists are included.
- PNG figures (`figures/`, binary), `data/`, `__pycache__/`: same as last time. The figures can be regenerated from the raw data with the analysis scripts.
- Template / reference directories that ship with the baseline zip but were deleted locally: no deletion patches generated (same as last time).
- Changes outside the repository: `preexp_env/env.sh` gains one line, `export TMPDIR=/home/ma-user/work/5446/tmp_textworld`
  (fast_downward keeps a mapped copy of libdownward.so for every TextWorld env, which can exhaust the container's /tmp quota); AgentBoard source
  `5446/third_party_dl/` (the required prompt / labels are already copied into `react_study/assets/`).
