# Incremental patch package application guide (round 3: directions A–F)

This set is the **incremental change** to `alfworld-preexp-npu` from the 2026-10-13 snapshot to the 2026-10-18 snapshot (round-3 experiments, directions A–F).
**It must be applied on top of the previous set `alfworld-patch-20261013`.**

Full chain: `cs5446-master.zip` (baseline commit `79d011256121bb23d96d6d7055c6f68a9fd6fdb9`)
→ `alfworld-patch-20261013` (24 packages) → **this set (`alfworld-patch-20261018`, 3 packages)**.

Each package is ≤ 50 KB gzipped. This file and `SHA256SUMS.txt` are identical in every package; `RESTORED_FILES.sha256` (checksums of all files this set touches, as on this machine) is in **part01** only.

Relative to the 20261013 state: **52 files (46 added / 6 modified), 4127 insertions(+), 4 deletions(-)**.

> **Verified on this machine**: unzip the baseline zip fresh → apply all of 20261013 (its `RESTORED_FILES.sha256` all OK) → `git apply --check` passes for this set → after applying, all 52 files in this set's `RESTORED_FILES.sha256` match this machine's SHA256 exactly.

---

## Package list

| Package | Files | Contents | Size (gzip) |
|---|---|---|---|
| `part01-code+results.tar.gz` | 28 (A22/M6) | `react_study/*.py`×10, `outputs/react_study/README.md`, `outputs/react_study/dirA_D_mechanism_dose/`×2, `outputs/react_study/dirB_planner_uncertainty/`×6, `outputs/react_study/dirC_interface/`×2, `outputs/react_study/dirE_larger_planner/`×6, `outputs/react_study/dirF_final_eval/` **+ RESTORED_FILES.sha256** | 30 KB |
| `part02-results+rawdata.tar.gz` | 23 (A23/M0) | `outputs/react_study/dirF_final_eval/`×6, `outputs/react_study/dirB_planner_uncertainty/`×2, `outputs/react_study/dirE_larger_planner/`×15 | 30 KB |
| `part03-rawdata.tar.gz` | 1 (A1/M0) | `outputs/react_study/dirE_larger_planner/` | 2 KB |
| `part04-results-per-rep-supplement.tar.gz` | 3 (A2/M1) | `outputs/react_study/step0_protocol_v2_measurement/` (per-run outcome CSV, 0c unbiased-subset CSV, README section) | 18 KB |

## How to apply

```bash
# 1. Unzip a clean baseline and apply the previous set first (see the APPLY.md inside alfworld-patch-20261013)
unzip cs5446-master.zip -d /path/to/dest
cd /path/to/dest/cs5446-master/alfworld-preexp-npu
mkdir -p /tmp/p13 /tmp/p18
for t in /path/to/alfworld-patch-20261013/part*.tar.gz; do tar xzf "$t" -C /tmp/p13 --strip-components=1; done
git apply /tmp/p13/*.patch && sha256sum -c --quiet /tmp/p13/RESTORED_FILES.sha256

# 2. Apply this set
for t in /path/to/alfworld-patch-20261018/part*.tar.gz; do tar xzf "$t" -C /tmp/p18 --strip-components=1; done
(cd /tmp/p18 && sha256sum -c SHA256SUMS.txt)
git apply --check /tmp/p18/*.patch
git apply /tmp/p18/*.patch

# 3. Verify restoration
sha256sum -c /tmp/p18/RESTORED_FILES.sha256
```

The target directory does not need to be a git repository.

## Supplement part04 (added 2026-10-18)
`step0_protocol_v2_measurement/tables/per_task_dev600_v2.csv` only had the per-task average over the 2 runs, so the Step 0c unbiased subset could not be reconstructed. part04 adds:
- `tables/per_task_per_rep_dev600.csv`: 600 tasks × {none, always} × {rep0, rep1}, each with success / progress / steps;
- `tables/branch_k_unbiased_points.csv`: 200 0c points, `in_unbiased_subset == 1` → 127 points / 81 tasks;
- a "Per-run outcomes" section in `step0_protocol_v2_measurement/README.md`.
part04 touches no files that part01–03 touch, so the four patches can be applied together.

## What changed in this round

**Code (`preexperiments/react_study/`, 10 files)**
- `agent.py`: new arms `none_resample` (identical-prompt resample, perturbation only), `explore_stuck` (T=0.7 resample when stuck), `fore_topk` (compare 3 candidates and their predicted outcomes), `fore_surprise` (show only predicted failures), `gate_unc` (planner-uncertainty pre-call gate), `unc_topk` (B+C combination).
- `protocol_v2.py`: every planner call records the mean logprob of the Action-line tokens (`action_line_lp`, decoding unchanged); new `sample_action` (temperature sampling).
- `gate.py`: `planner_uncertain` (threshold from `dirB_planner_uncertainty/tables/gate_unc_calibration.json`).
- `common.py`: planner roles can be routed to a separate model / endpoints (`PREEXP_PLANNER_BASES` / `PREEXP_PLANNER_MODEL` / `PREEXP_PLANNER_CHAT_KWARGS`, for direction E's 14B); round-3 output directories.
- `run_episodes.py`: `--label` (overrides the arm name written to rows).
- New: `dirB_offline.py`, `dirB_sign_offline.py`, `analyze_round3.py`, `dirF_test.py`, `dirE_analyze.py`.

**Results (`outputs/react_study/`)**
- `dirA_D_mechanism_dose/`, `dirB_planner_uncertainty/`, `dirC_interface/`, `dirE_larger_planner/`, `dirF_final_eval/`: READMEs, tables (`*.md` / `*.json`), launch scripts.
- `dirB_planner_uncertainty/raw/signals.jsonl`, `sign_offline.jsonl`: state-level data from the offline screens (needed to re-run them).
- `dirE_larger_planner/raw/oracle_rest_rep*_part*`: re-split task lists.
- `outputs/react_study/README.md`: round-3 summary appended.

## Not included (same as last time)
- Episode-level raw JSONL (`*/raw/train/*__rep*.jsonl`, `*/raw/eval_out_of_distribution/*`), run `logs/`: too large for small packages; every conclusion is in the included tables / READMEs.
- PNG figures (this round: `dirF_final_eval/figures/dose_response_dev460.png`), binary; can be regenerated from the raw data with `analyze_round3.py`.
- Changes outside the repository: `preexp_env/dl_parallel.py` (parallel model downloader), `preexp_env/models/Qwen3-14B/` (Qwen/Qwen3-14B from ModelScope, 29.6 GB, SHA256 verified).
