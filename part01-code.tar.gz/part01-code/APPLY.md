# Incremental patch package application guide (rounds 4–5: router study, failure-triggered repair)

This set is the **incremental change** to `alfworld-preexp-npu` from the 2026-10-18 snapshot to the 2026-10-23 snapshot
(round 4: full research plan, phases 0–4 + failure analysis + feasibility probes; round 5: repair-oriented foresight,
stage A method selection and stage B frozen evaluation).
**It must be applied on top of `alfworld-patch-20261013` and `alfworld-patch-20261018`.**

Full chain: `cs5446-master.zip` (baseline commit `79d011256121bb23d96d6d7055c6f68a9fd6fdb9`)
→ `alfworld-patch-20261013` (24 packages) → `alfworld-patch-20261018` (4 packages) → **this set (`alfworld-patch-20261023`, 6 packages)**.

Each package is ≤ 50 KB gzipped. This file and `SHA256SUMS.txt` are identical in every package; `RESTORED_FILES.sha256`
(checksums of all files this set touches, as on this machine) is in **part01** only.

Relative to the 20261018 state: **73 files (68 added / 5 modified), 18501 insertions(+), 7 deletions(-)**.
Every file is in exactly one package, so the packages can be applied together in any order.

> **Verified on this machine**: unzip the baseline zip fresh → apply 20261013 (`RESTORED_FILES.sha256` all OK) → apply
> 20261018 (all OK) → `git apply --check` passes for this set → after applying, all 73 files in this set's
> `RESTORED_FILES.sha256` match this machine's SHA256 exactly.

---

## Package list

| Package | Files | Contents |
|---|---|---|
| `part01-code.tar.gz` | 11 (A9/M2) | `react_study` **+ RESTORED_FILES.sha256** |
| `part02-results+rawdata.tar.gz` | 3 (A3/M0) | `p4_router`, `p7_final`, `r4_common` |
| `part03-docs+results.tar.gz` | 3 (A3/M0) | `p2_branch_labels`, `probe_feasibility` |
| `part04-docs+results+rawdata.tar.gz` | 6 (A5/M1) | `README.md`, `p2_branch_labels`, `r4_common` |
| `part05-code+docs+results+rawdata.tar.gz` | 15 (A15/M0) | `p2_branch_labels`, `p3_mechanism_matrix`, `p7_final`, `probe_feasibility`, `r4_common`, `react_study` |
| `part06-code+docs+results+rawdata.tar.gz` | 35 (A33/M2) | `failure_analysis`, `p1_wm_capability`, `p2_branch_labels`, `p3_mechanism_matrix`, `p4_router`, `p7_final`, `probe_feasibility`, `r4_common`, `react_study` |

## How to apply

```bash
# 1. Unzip a clean baseline and apply the two previous sets (see their APPLY.md)
unzip cs5446-master.zip -d /path/to/dest
cd /path/to/dest/cs5446-master/alfworld-preexp-npu
mkdir -p /tmp/p13 /tmp/p18 /tmp/p23
for t in /path/to/alfworld-patch-20261013/part*.tar.gz; do tar xzf "$t" -C /tmp/p13 --strip-components=1; done
git apply /tmp/p13/*.patch && sha256sum -c --quiet /tmp/p13/RESTORED_FILES.sha256
for t in /path/to/alfworld-patch-20261018/part*.tar.gz; do tar xzf "$t" -C /tmp/p18 --strip-components=1; done
git apply /tmp/p18/*.patch && sha256sum -c --quiet /tmp/p18/RESTORED_FILES.sha256

# 2. Apply this set
for t in /path/to/alfworld-patch-20261023/part*.tar.gz; do tar xzf "$t" -C /tmp/p23 --strip-components=1; done
(cd /tmp/p23 && sha256sum -c SHA256SUMS.txt)
git apply --check /tmp/p23/*.patch
git apply /tmp/p23/*.patch

# 3. Verify restoration
sha256sum -c /tmp/p23/RESTORED_FILES.sha256
```

The target directory does not need to be a git repository.

## What changed in this round

**Code (`preexperiments/react_study/`, 4 modified + 11 new)**
- `agent.py`: TextWorld env leak fix (registry entries dropped after `init_env`; `libdownward.so` copies pooled and reused
  instead of one 34 MB copy per env — the leak filled the data disk on 2026-10-19); `WM_ROLE` (route WM calls to a second
  model); random-gated mechanism arms `resample_pre` / `resample0_pre` / `oracle_pre`; router arms `route` / `route_rand`;
  failure-gated arms (`a_base` not admissible) `inv_resample`, `inv_fail`, `inv_repair` (oracle diagnosis), `inv_proj`
  (admissibility projection), `inv_wmrepair` (frozen-WM diagnosis + repair, **the round-5 method**), `inv_reflect`,
  `inv_sreflect`, `inv_rules`, `inv_state`, `inv_wmpred`; post-execution trigger `post_wmrepair`.
- `common.py`: role `wm_alt` (`PREEXP_WM_ALT_BASES/MODEL/CHAT_KWARGS`, e.g. Qwen3-14B as WM); stages 30–39.
- `protocol_v2.py`: `project_action` (keep Thought, re-decode the action with guided_choice over admissible actions).
- `run_episodes.py`: `--wm_role`, `--router`, `--route_pR/--route_pW`; run configs record endpoints/models.
- New: `branch_r4.py` (same-state 0/R0/RT/W4/W14/oracle branching, continuation reuse, regen), `sample_points_r4.py`,
  `analyze_p2.py`, `analyze_p3.py`, `wm_capability_r4.py`, `router.py`, `preconditions.py` (state tracking, oracle
  diagnosis, prompts and blocks for all repair / reflection / rule-card arms), `analyze_probe.py`, `analyze_round5.py`,
  `analyze_final.py`, `failure_analysis.py`.

**Results (`outputs/react_study/`)** — READMEs, tables (`*.md` / `*.json`), pre-registrations, launch scripts:
- `r4_common/`: serving and endpoint scripts, frozen data split (`raw/split_manifest.json`, `fresh_test600_games.txt`,
  `label_pool500_games.txt`, `branch140_games.txt`, `used_train_trial_ids.json`, `unbiased127_point_ids.txt`), power plan.
- `p1_wm_capability/`, `p2_branch_labels/` (incl. `raw/p14b_branch140_points.jsonl`), `p3_mechanism_matrix/`,
  `p4_router/` (incl. `raw/p4b_label_points.jsonl`), `failure_analysis/`, `probe_feasibility/` (round-4 probes and
  round-5 stage A), `p7_final/` (round-5 stage B, incl. `raw/fresh600_chunk*`).
- `outputs/react_study/README.md`: round-4 and round-5 summary appended.

## Not included (same policy as before)
- Episode-level raw JSONL (`*/raw/train/*__rep*.jsonl`, `*/raw/eval_out_of_distribution/*`, ~1.6 GB) and run `logs/`.
- Branch-label rows (`p2_branch_labels/raw/*.shard*.jsonl`, `p4_router/raw/*.shard*.jsonl`, ~7.6 MB) and
  `p1_wm_capability/raw/wm_capability.jsonl`: state-level rows with all continuations; the state points needed to
  regenerate them are included, and every conclusion is in the included tables / READMEs.
- Smoke-test outputs (`r4_common/raw/train/smoke*`), `r4_common/backup_truncated_20261021/` (2 rows truncated by the
  full disk, removed and re-run).
- Files outside the repository: plans/reports in `/home/ma-user/work/5446/`
  (`react_study_full_research_plan_20261019.md`, `react_study_round5_plan_20261021.md`, cross-round reviews), and the
  served models (Qwen3-4B-Instruct-2507, Qwen3-14B, unchanged).
